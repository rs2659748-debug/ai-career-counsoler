
import React, { useState, useEffect, useRef } from 'react';
import { CounselingStep, UserData, Message, STEP_ORDER, STEP_QUESTIONS } from './types';
import { 
  getCareerAnalysis, 
  getRoadmap, 
  getAdjustment, 
  getDetailedCareerInfo, 
  getFriendlyGreeting, 
  getSpeech,
  askCareerQuestion
} from './services/geminiService';
import MarkdownRenderer from './components/MarkdownRenderer';
import CareerModal from './components/CareerModal';

// Audio Helpers
function decode(base64: string) {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const App: React.FC = () => {
  const [stepIndex, setStepIndex] = useState(0);
  const [messages, setMessages] = useState<Message[]>([]);
  const [userInput, setUserInput] = useState('');
  const [userData, setUserData] = useState<UserData>({
    education: '',
    field: '',
    techSkills: '',
    softSkills: '',
    interests: '',
    goals: '',
    experience: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [analysisResult, setAnalysisResult] = useState('');
  const [suggestedCareers, setSuggestedCareers] = useState<string[]>([]);
  const [isSpeaking, setIsSpeaking] = useState<number | null>(null);
  
  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalCareer, setModalCareer] = useState('');
  const [modalContent, setModalContent] = useState('');
  const [isModalLoading, setIsModalLoading] = useState(false);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading, suggestedCareers]);

  useEffect(() => {
    const initialMessage: Message = {
      role: 'assistant',
      content: STEP_QUESTIONS[CounselingStep.GREETING]
    };
    setMessages([initialMessage]);
  }, []);

  const handleError = async (error: any) => {
    console.error(error);
    const errorMessage = error?.message || error?.toString() || "";
    if (errorMessage.includes("Requested entity was not found")) {
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: "It seems the requested model is not available or the API key project configuration needs updating. Please select a valid API key from a paid GCP project." 
      }]);
      // @ts-ignore
      if (window.aistudio && typeof window.aistudio.openSelectKey === 'function') {
        // @ts-ignore
        await window.aistudio.openSelectKey();
      }
    } else {
      setMessages(prev => [...prev, { role: 'assistant', content: "I encountered an error. Please check your connection or try again." }]);
    }
  };

  const handlePlayAudio = async (text: string, msgIndex: number) => {
    if (isSpeaking !== null) return;
    setIsSpeaking(msgIndex);
    
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      const ctx = audioContextRef.current;
      const base64Audio = await getSpeech(text);
      const audioBytes = decode(base64Audio);
      const audioBuffer = await decodeAudioData(audioBytes, ctx, 24000, 1);
      
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      source.onended = () => setIsSpeaking(null);
      source.start();
    } catch (error) {
      handleError(error);
      setIsSpeaking(null);
    }
  };

  const parseCareers = (text: string) => {
    const match = text.match(/\[CAREERS:\s*(.*?)\]/);
    if (match && match[1]) {
      const careers = match[1].split(',').map(c => c.trim()).filter(c => c);
      setSuggestedCareers(careers);
    }
    return text;
  };

  const handleExploreCareer = async (career: string) => {
    setModalCareer(career);
    setIsModalOpen(true);
    setIsModalLoading(true);
    try {
      const details = await getDetailedCareerInfo(career, userData);
      setModalContent(details);
    } catch (error) {
      handleError(error);
      setModalContent("Sorry, I couldn't fetch the detailed information. Check your internet connection.");
    } finally {
      setIsModalLoading(false);
    }
  };

  const currentStep = STEP_ORDER[stepIndex];

  const handleSend = async () => {
    if (!userInput.trim() || isLoading) return;

    const newUserMessage: Message = { role: 'user', content: userInput };
    setMessages(prev => [...prev, newUserMessage]);
    const currentInput = userInput;
    setUserInput('');

    setIsLoading(true);
    const nextIdx = stepIndex + 1;

    try {
      if (currentStep === CounselingStep.GREETING) {
        const aiResponse = await getFriendlyGreeting(currentInput);
        setMessages(prev => [...prev, { role: 'assistant', content: aiResponse }]);
        setStepIndex(nextIdx);
      } else if (stepIndex >= STEP_ORDER.indexOf(CounselingStep.ROADMAP)) {
        // Post-session Chat Mode (Gemini 3 Pro)
        const history = messages.slice(-10);
        const aiResponse = await askCareerQuestion(currentInput, history);
        setMessages(prev => [...prev, { role: 'assistant', content: aiResponse }]);
      } else {
        // Data gathering steps
        const updatedData = { ...userData };
        const fieldMap: Record<string, keyof UserData | null> = {
          [CounselingStep.EDUCATION]: 'education',
          [CounselingStep.FIELD_OF_STUDY]: 'field',
          [CounselingStep.TECH_SKILLS]: 'techSkills',
          [CounselingStep.SOFT_SKILLS]: 'softSkills',
          [CounselingStep.INTERESTS]: 'interests',
          [CounselingStep.GOALS]: 'goals',
          [CounselingStep.EXPERIENCE]: 'experience',
        };

        const field = fieldMap[currentStep];
        if (field) {
          updatedData[field] = currentInput;
          setUserData(updatedData);
        }

        if (nextIdx < STEP_ORDER.length) {
          const nextStep = STEP_ORDER[nextIdx];
          setStepIndex(nextIdx);

          if (nextStep === CounselingStep.ANALYSIS) {
            const rawAnalysis = await getCareerAnalysis(updatedData);
            const cleanedAnalysis = parseCareers(rawAnalysis);
            setAnalysisResult(cleanedAnalysis);
            setMessages(prev => [...prev, { role: 'assistant', content: cleanedAnalysis }, { role: 'assistant', content: STEP_QUESTIONS[nextStep] }]);
          } else if (nextStep === CounselingStep.ROADMAP) {
            const roadmap = await getRoadmap(updatedData, analysisResult);
            setMessages(prev => [...prev, { role: 'assistant', content: roadmap }, { role: 'assistant', content: STEP_QUESTIONS[nextStep] }]);
          } else {
            setMessages(prev => [...prev, { role: 'assistant', content: STEP_QUESTIONS[nextStep] }]);
          }
        } else {
          const adjustment = await getAdjustment(updatedData, currentInput);
          setMessages(prev => [...prev, { role: 'assistant', content: "Adjusting based on your feedback..." }, { role: 'assistant', content: parseCareers(adjustment) }]);
        }
      }
    } catch (error) {
      handleError(error);
    } finally {
      setIsLoading(false);
    }
  };

  const progress = ((stepIndex + 1) / STEP_ORDER.length) * 100;

  return (
    <div className="flex flex-col h-screen max-w-5xl mx-auto bg-white shadow-2xl border-x border-slate-200">
      <header className="p-6 bg-slate-900 text-white flex justify-between items-center shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2v8"/><path d="m16 6-4 4-4-4"/><path d="M12 18v4"/><path d="m8 20 4-4 4 4"/><path d="m5 12 14 0"/><path d="m12 5 0 14"/></svg>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">CareerCounsel AI</h1>
            <p className="text-blue-400 text-[10px] uppercase font-bold tracking-widest">Powered by Gemini 3 Pro</p>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1">
          <div className="text-[10px] text-slate-400 uppercase font-bold tracking-tighter">Session Progress</div>
          <div className="w-48 bg-slate-700 h-2 rounded-full overflow-hidden border border-slate-800">
            <div className="bg-blue-500 h-full transition-all duration-700 ease-in-out" style={{ width: `${progress}%` }} />
          </div>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-4 md:p-10 space-y-8 bg-slate-50/30">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2 duration-300`}>
            <div className={`group relative max-w-[90%] md:max-w-[85%] rounded-3xl px-6 py-5 shadow-sm border ${
              msg.role === 'user' 
                ? 'bg-blue-600 text-white border-blue-500' 
                : 'bg-white text-slate-800 border-slate-200'
            }`}>
              {msg.role === 'assistant' && (
                <button 
                  onClick={() => handlePlayAudio(msg.content, i)}
                  className={`absolute -right-12 top-2 p-2 rounded-full transition-all ${
                    isSpeaking === i ? 'bg-blue-100 text-blue-600 scale-110' : 'bg-white text-slate-400 hover:text-blue-500 border border-slate-200 opacity-0 group-hover:opacity-100'
                  }`}
                  title="Listen to advice"
                >
                  {isSpeaking === i ? (
                    <div className="flex gap-0.5">
                      <div className="w-1 h-3 bg-blue-600 animate-bounce" />
                      <div className="w-1 h-3 bg-blue-600 animate-bounce [animation-delay:0.1s]" />
                      <div className="w-1 h-3 bg-blue-600 animate-bounce [animation-delay:0.2s]" />
                    </div>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>
                  )}
                </button>
              )}
              {msg.role === 'assistant' ? <MarkdownRenderer content={msg.content} /> : <p className="whitespace-pre-wrap">{msg.content}</p>}
            </div>
          </div>
        ))}

        {suggestedCareers.length > 0 && (
          <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm space-y-6 animate-in zoom-in-95 duration-500">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Research & Growth Center</h3>
                <p className="text-sm text-slate-500">Explore real-time data for these recommended paths.</p>
              </div>
              <div className="bg-emerald-50 text-emerald-600 text-[10px] px-2 py-1 rounded font-bold border border-emerald-100 flex items-center gap-1">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                LIVE MARKET DATA
              </div>
            </div>
            <div className="flex flex-wrap gap-3">
              {suggestedCareers.map((career, i) => (
                <button
                  key={i}
                  onClick={() => handleExploreCareer(career)}
                  className="group bg-slate-50 border border-slate-200 hover:bg-white hover:border-blue-400 hover:text-blue-600 px-5 py-3 rounded-2xl text-sm font-semibold shadow-sm transition-all hover:-translate-y-1 active:scale-95 flex items-center gap-2"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="text-slate-400 group-hover:text-blue-500" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                  Analyze: {career}
                </button>
              ))}
            </div>
          </div>
        )}

        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white rounded-3xl px-8 py-5 border border-slate-200 flex flex-col gap-3 shadow-sm min-w-[200px]">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-10 h-10 border-4 border-slate-100 border-t-blue-600 rounded-full animate-spin" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-2 h-2 bg-blue-600 rounded-full animate-pulse" />
                  </div>
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-800">Thinking Mode</div>
                  <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Allocating 32k Tokens</div>
                </div>
              </div>
              <p className="text-slate-400 text-xs italic">Counselor is reasoning through complex career data...</p>
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </main>

      <footer className="p-6 border-t border-slate-200 bg-white shrink-0">
        <div className="flex gap-4">
          <textarea
            rows={1}
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder={stepIndex >= STEP_ORDER.indexOf(CounselingStep.ROADMAP) ? "Ask any follow-up questions..." : "Enter your response..."}
            className="flex-1 bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 focus:bg-white resize-none transition-all text-blue-900 font-medium text-lg placeholder:text-slate-400"
          />
          <button
            onClick={handleSend}
            disabled={!userInput.trim() || isLoading}
            className={`px-10 rounded-2xl font-bold transition-all flex items-center gap-3 active:scale-95 shadow-lg ${
              !userInput.trim() || isLoading
                ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                : 'bg-blue-600 text-white hover:bg-blue-700 hover:shadow-blue-500/20 shadow-blue-600/20'
            }`}
          >
            {isLoading ? '...' : 'Send'}
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
          </button>
        </div>
      </footer>

      <CareerModal 
        careerName={modalCareer}
        content={modalContent}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        isLoading={isModalLoading}
      />
    </div>
  );
};

export default App;
