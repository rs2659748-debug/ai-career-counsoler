
import React from 'react';
import MarkdownRenderer from './MarkdownRenderer';

interface CareerModalProps {
  careerName: string;
  content: string;
  isOpen: boolean;
  onClose: () => void;
  isLoading: boolean;
}

const CareerModal: React.FC<CareerModalProps> = ({ careerName, content, isOpen, onClose, isLoading }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-4xl rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in slide-in-from-bottom-8 duration-500 border border-white/20">
        <header className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
          <div className="space-y-1">
            <div className="flex items-center gap-2 mb-1">
               <span className="bg-blue-100 text-blue-700 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest">Research Module</span>
               <span className="bg-slate-900 text-white text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest flex items-center gap-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/></svg>
                Google Search Grounded
               </span>
            </div>
            <h2 className="text-3xl font-black text-slate-900 leading-tight">{careerName}</h2>
            <p className="text-slate-500 text-sm font-medium">In-depth market analysis and future outlook</p>
          </div>
          <button 
            onClick={onClose}
            className="p-3 hover:bg-white hover:shadow-sm rounded-full transition-all text-slate-400 hover:text-slate-900 border border-transparent hover:border-slate-200"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
          </button>
        </header>
        
        <div className="flex-1 overflow-y-auto p-8 md:p-12">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-20 space-y-6">
              <div className="relative">
                <div className="w-16 h-16 border-4 border-blue-50 border-t-blue-600 rounded-full animate-spin" />
                <div className="absolute inset-0 flex items-center justify-center">
                   <svg xmlns="http://www.w3.org/2000/svg" className="text-blue-600 animate-pulse" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                </div>
              </div>
              <div className="text-center space-y-2">
                <p className="text-slate-900 font-bold text-xl">Querying Google Search...</p>
                <p className="text-slate-500 font-medium">Validating salary data and industry trends for 2024</p>
              </div>
            </div>
          ) : (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-700 delay-200">
               <MarkdownRenderer content={content} />
            </div>
          )}
        </div>

        <footer className="p-6 border-t border-slate-100 bg-slate-50/50 flex justify-end">
          <button 
            onClick={onClose}
            className="px-10 py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-slate-800 transition-all active:scale-95 shadow-lg shadow-slate-900/10"
          >
            Done Researching
          </button>
        </footer>
      </div>
    </div>
  );
};

export default CareerModal;
