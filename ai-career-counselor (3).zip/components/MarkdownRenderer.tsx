
import React from 'react';

interface MarkdownRendererProps {
  content: string;
}

const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  const lines = content.split('\n');

  // Simple table parser to group table lines
  const elements: React.ReactNode[] = [];
  let currentTable: string[][] = [];

  const renderTable = (rows: string[][], key: number) => {
    if (rows.length < 2) return null;
    const headers = rows[0];
    const data = rows.slice(2); // Skip header and separator row

    return (
      <div key={`table-${key}`} className="overflow-x-auto my-6 rounded-xl border border-slate-200 shadow-sm">
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-slate-700 uppercase bg-slate-50 border-b border-slate-200">
            <tr>
              {headers.map((h, i) => (
                <th key={i} className="px-4 py-3 font-bold">{h.trim()}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {data.map((row, rowIndex) => (
              <tr key={rowIndex} className="bg-white hover:bg-slate-50 transition-colors">
                {row.map((cell, cellIndex) => {
                  const trimmed = cell.trim();
                  const headerName = headers[cellIndex]?.toLowerCase().trim() || "";
                  
                  // Check if this is a score column
                  const isScore = /^\d+$/.test(trimmed) || (trimmed.endsWith('%') && /^\d+%$/.test(trimmed));
                  const isDidYouKnow = headerName.includes("did you know");

                  if (isScore) {
                    const score = parseInt(trimmed);
                    return (
                      <td key={cellIndex} className="px-4 py-3 min-w-[120px]">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                            <div 
                              className={`h-full transition-all duration-1000 ${
                                score > 80 ? 'bg-emerald-500' : score > 60 ? 'bg-blue-500' : 'bg-amber-500'
                              }`}
                              style={{ width: `${score}%` }}
                            />
                          </div>
                          <span className="font-semibold text-slate-700">{score}%</span>
                        </div>
                      </td>
                    );
                  }

                  if (isDidYouKnow) {
                    return (
                      <td key={cellIndex} className="px-4 py-3 bg-amber-50/30">
                        <div className="flex gap-2">
                          <span className="text-amber-500 mt-0.5 shrink-0">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/></svg>
                          </span>
                          <span className="text-slate-600 italic leading-snug">{trimmed}</span>
                        </div>
                      </td>
                    );
                  }

                  return (
                    <td key={cellIndex} className="px-4 py-3 text-slate-600 leading-relaxed">
                      {trimmed}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  let i = 0;
  while (i < lines.length) {
    const line = lines[i].trim();

    if (line.startsWith('|')) {
      // Start of a table
      currentTable = [];
      while (i < lines.length && lines[i].trim().startsWith('|')) {
        const row = lines[i].split('|').filter((_, idx, arr) => idx > 0 && idx < arr.length - 1);
        currentTable.push(row);
        i++;
      }
      elements.push(renderTable(currentTable, i));
      continue;
    }

    if (line.startsWith('- ') || line.startsWith('* ')) {
      elements.push(<li key={i} className="ml-6 mb-1 list-disc text-slate-700">{lines[i].trim().substring(2)}</li>);
    } else if (line.match(/^\d+\./)) {
      elements.push(<li key={i} className="ml-6 mb-1 list-decimal text-slate-700">{lines[i].trim().replace(/^\d+\.\s*/, '')}</li>);
    } else if (line.startsWith('#')) {
      const level = line.match(/^#+/)?.[0].length || 1;
      const text = line.replace(/^#+\s*/, '');
      const classes = level === 1 ? "text-2xl font-bold mt-8 mb-4 text-slate-900 border-b pb-2" : "text-xl font-bold mt-6 mb-2 text-slate-800";
      elements.push(<div key={i} className={classes}>{text}</div>);
    } else if (line !== '') {
      elements.push(<p key={i} className="mb-4 text-slate-700 leading-relaxed">{lines[i]}</p>);
    } else {
      elements.push(<div key={i} className="h-2" />);
    }
    i++;
  }

  return (
    <div className="markdown-content">
      {elements}
    </div>
  );
};

export default MarkdownRenderer;
