
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { UserData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

/**
 * Low-latency greeting using Flash Lite
 */
export const getFriendlyGreeting = async (userGreeting: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-flash-lite-latest',
    contents: `You are a professional and warm Career Guidance Counselor. The user just said: "${userGreeting}". Acknowledge their greeting politely. Briefly explain that you will ask a few questions to find their career path. End by asking: "To get started, what is your current education level?"`,
  });
  return response.text;
};

/**
 * Conversational response for small talk
 */
export const getConversationalResponse = async (userInput: string, context: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-flash-lite-latest',
    contents: `You are a professional AI Career Counselor. Context: ${context}. User just said: "${userInput}". Respond naturally and briefly (1-2 sentences).`,
  });
  return response.text;
};

/**
 * Complex analysis with Thinking Mode (Gemini 3 Pro)
 */
export const getCareerAnalysis = async (userData: UserData) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Act as a professional career counselor. Analyze this profile: ${JSON.stringify(userData)}. 
    Generate 3-5 career options with scores. Use markdown table. 
    Include columns: Career | Suitability Score | Detailed Alignment Reasoning | Did You Know?
    End with [CAREERS: Career1, Career2, ...]`,
    config: {
      thinkingConfig: { thinkingBudget: 32768 }
    }
  });
  return response.text;
};

/**
 * Roadmap generation with Thinking Mode (Gemini 3 Pro)
 */
export const getRoadmap = async (userData: UserData, analysis: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Based on this analysis: ${analysis} and user profile: ${JSON.stringify(userData)}, create a Skill Gap Analysis and a detailed Beginner-to-Advanced Learning Roadmap for the top choices.`,
    config: {
      thinkingConfig: { thinkingBudget: 32768 }
    }
  });
  return response.text;
};

/**
 * Real-time career research using Search Grounding (Gemini 3 Flash)
 */
export const getDetailedCareerInfo = async (careerName: string, userData: UserData) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Provide a detailed real-time career profile for "${careerName}". Use Google Search to find up-to-date salary ranges, emerging responsibilities, and key industry trends for 2024-2025. Background: ${userData.education}. Format in markdown.`,
    config: {
      tools: [{ googleSearch: {} }]
    }
  });
  
  // Extracting search sources for transparency
  const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  let sourceLinks = "";
  if (sources.length > 0) {
    sourceLinks = "\n\n**Sources:**\n" + sources
      .map((c: any) => c.web ? `- [${c.web.title || 'Source'}](${c.web.uri})` : null)
      .filter(Boolean)
      .join("\n");
  }

  return response.text + sourceLinks;
};

/**
 * Feedback adjustments with Thinking Mode (Gemini 3 Pro)
 */
export const getAdjustment = async (userData: UserData, feedback: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `The user feedback is: "${feedback}". Adjust their profile: ${JSON.stringify(userData)}. Re-run career analysis and roadmap. Include [CAREERS: ...]`,
    config: {
      thinkingConfig: { thinkingBudget: 32768 }
    }
  });
  return response.text;
};

/**
 * Text-to-Speech (Gemini 2.5 Flash Preview TTS)
 */
export const getSpeech = async (text: string): Promise<string> => {
  // Clean text of markdown before speaking
  const cleanText = text.replace(/[#*|`\[\]\(\)]/g, '').slice(0, 1000); 
  
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Read this career advice warmly: ${cleanText}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("No audio data received");
  return base64Audio;
};

/**
 * Free-form chatbot for arbitrary questions (Gemini 3 Pro)
 */
export const askCareerQuestion = async (question: string, history: any[]) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `You are a expert Career Counselor. Answer this question: "${question}". Conversation History for context: ${JSON.stringify(history)}`,
    config: {
      thinkingConfig: { thinkingBudget: 32768 }
    }
  });
  return response.text;
};
