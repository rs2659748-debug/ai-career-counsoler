
export enum CounselingStep {
  GREETING = 'GREETING',
  EDUCATION = 'EDUCATION',
  FIELD_OF_STUDY = 'FIELD_OF_STUDY',
  TECH_SKILLS = 'TECH_SKILLS',
  SOFT_SKILLS = 'SOFT_SKILLS',
  INTERESTS = 'INTERESTS',
  GOALS = 'GOALS',
  EXPERIENCE = 'EXPERIENCE',
  ANALYSIS = 'ANALYSIS',
  ROADMAP = 'ROADMAP',
  FEEDBACK = 'FEEDBACK'
}

export interface UserData {
  education: string;
  field: string;
  techSkills: string;
  softSkills: string;
  interests: string;
  goals: string;
  experience: string;
}

export interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export const STEP_ORDER: CounselingStep[] = [
  CounselingStep.GREETING,
  CounselingStep.EDUCATION,
  CounselingStep.FIELD_OF_STUDY,
  CounselingStep.TECH_SKILLS,
  CounselingStep.SOFT_SKILLS,
  CounselingStep.INTERESTS,
  CounselingStep.GOALS,
  CounselingStep.EXPERIENCE,
  CounselingStep.ANALYSIS,
  CounselingStep.ROADMAP,
  CounselingStep.FEEDBACK
];

export const STEP_QUESTIONS: Record<CounselingStep, string> = {
  [CounselingStep.GREETING]: "Hello! I am your AI Career Guidance Counselor. I'm here to help you map out your professional future and find a path that truly resonates with your skills and passions. \n\nAre you ready to begin our session?",
  [CounselingStep.EDUCATION]: "Thank you. What is your primary field of study?",
  [CounselingStep.FIELD_OF_STUDY]: "Great. What technical skills do you possess (e.g., programming languages, specific tools, or software)?",
  [CounselingStep.TECH_SKILLS]: "Excellent. What would you say are your strongest soft skills (e.g., communication, leadership, problem-solving)?",
  [CounselingStep.SOFT_SKILLS]: "What are your main interests? Think about subjects, activities, or specific domains you enjoy.",
  [CounselingStep.INTERESTS]: "What are your long-term career goals? (e.g., getting a job in a specific industry, higher studies, starting a business)?",
  [CounselingStep.GOALS]: "Lastly, what is your current experience level in your field of interest? (Beginner, Intermediate, or Advanced)",
  [CounselingStep.EXPERIENCE]: "Thank you for sharing that. I'm now analyzing your profile to suggest the best career paths for you...",
  [CounselingStep.ANALYSIS]: "Here is my analysis of your career options. Should we proceed to look at the skill gaps and your personalized learning roadmap?",
  [CounselingStep.ROADMAP]: "Based on the top choices, here is your detailed skill gap analysis and learning roadmap.",
  [CounselingStep.FEEDBACK]: "Do these recommendations match your expectations? If not, let me know what you'd like to adjust!"
};
